<?php

namespace Aislin_Testimonials\Shortcodes\Shortcodes;

class Rotator extends Shortcode {
	const NAME     = 'aislin_testimonial_rotator';
	const TEMPLATE = \Aislin_Testimonials\Render\Rotator::class;
}
