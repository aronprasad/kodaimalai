<?php

namespace Aislin_Testimonials\Shortcodes\Shortcodes;

class Testimonial extends Shortcode {
	const NAME     = 'aislin_testimonial';
	const TEMPLATE = \Aislin_Testimonials\Render\Testimonial::class;
}
