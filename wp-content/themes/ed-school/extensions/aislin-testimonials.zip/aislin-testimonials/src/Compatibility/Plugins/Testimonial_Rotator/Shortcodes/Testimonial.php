<?php

namespace Aislin_Testimonials\Compatibility\Plugins\Testimonial_Rotator\Shortcodes;

use Aislin_Testimonials\Shortcodes\Shortcodes;

class Testimonial extends Shortcodes\Testimonial {
	const NAME = 'testimonial_single';
}
