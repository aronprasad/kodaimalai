<?php

namespace Aislin_Testimonials\Compatibility\Plugins\Testimonial_Rotator\Shortcodes;

use Aislin_Testimonials\Shortcodes\Shortcodes;

class Rotator_Alt extends Shortcodes\Rotator {
	const NAME = 'testimonial-rotator';
}
