<?php
/**
 * Product Loop Start
 */
?>
<div class="msm-wc-products">
