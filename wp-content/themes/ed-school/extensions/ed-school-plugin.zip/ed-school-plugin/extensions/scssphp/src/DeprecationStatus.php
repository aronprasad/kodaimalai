<?php

namespace ScssPhp\ScssPhp;

enum DeprecationStatus
{
    case active;
    case user;
    case future;
    case obsolete;
}
