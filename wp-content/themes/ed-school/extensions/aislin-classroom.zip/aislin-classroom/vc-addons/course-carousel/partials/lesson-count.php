<div class="cbp-row">
	<div class="one whole">
		<div class="course-lesson-count">			
			<i class="icon-skilledtime4"></i>
        	<?php echo esc_html( $lesson_count ) . '&nbsp;' .  esc_html__( 'Lessons', 'aislin-classroom' ); ?>
		</div>
        <div class="course-lesson-count author">
        <i class="icon-skilledround-account-button-with-user-inside2"></i>
        	<?php echo wp_kses_post( get_the_author() ); ?>
        </div>
	</div>
</div>